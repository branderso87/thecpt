##Brandi Anderson's cPanel UI Developer Javascript Test

Thanks for giving me the opportunity to take this skills test. I've included the javascript in a seperate file (main.js) as well as a proxy server (proxyserver.js) and css file (master.css) where I have gone ahead and styled the test based on your current site.

If you have any questions or comments please feel free to contact me at:

* email: branderso87@gmail.com
* phone: (832)443-3891
* website: thebrandianderson.com

## Install

* run npm install
  - to install all of the modules used from the package.json file.
* node start
  - to start the proxy server before opening the html page.

Thanks again,
Brandi Anderson
